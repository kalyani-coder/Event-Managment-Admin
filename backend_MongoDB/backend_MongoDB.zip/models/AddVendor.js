const mongoose = require('mongoose')

const AddVendor = new mongoose.Schema({

    Vendor_Name : {
        typeof : String
    },

})